-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: hrmdb_dev
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES (1,'Twist','');
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Emergency`
--

DROP TABLE IF EXISTS `Emergency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Emergency` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) NOT NULL,
  `contact_person` varchar(90) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `mobile` varchar(13) DEFAULT NULL,
  `landline` varchar(15) DEFAULT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_emergency_employee_id_idx` (`employee_id`),
  CONSTRAINT `fk_emergency_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Emergency`
--

LOCK TABLES `Emergency` WRITE;
/*!40000 ALTER TABLE `Emergency` DISABLE KEYS */;
INSERT INTO `Emergency` VALUES (1,1,'Emergency 1',NULL,NULL,NULL,NULL,NULL,NULL,'2018-07-23 09:26:19',NULL),(2,1,'Emergency 2',NULL,NULL,NULL,NULL,NULL,NULL,'2018-07-23 09:26:30',NULL),(3,1,'Emergency 3',NULL,NULL,NULL,NULL,NULL,NULL,'2018-07-23 09:26:37',NULL),(4,40,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-23 14:20:54',NULL),(10,49,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-23 14:31:49',NULL),(11,51,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-23 15:48:42',NULL),(12,54,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-24 13:44:45',NULL),(13,56,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-24 13:45:09',NULL),(14,57,'fgh','fgh','fgh','fgh','fgh',NULL,NULL,'2018-07-24 14:18:40',NULL);
/*!40000 ALTER TABLE `Emergency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) NOT NULL,
  `loginservice_id` varchar(45) NOT NULL,
  `employee_number` varchar(20) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `mobile` varchar(13) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `landline` varchar(15) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `tin` varchar(20) DEFAULT NULL,
  `sss` varchar(20) DEFAULT NULL,
  `philhealth` varchar(20) DEFAULT NULL,
  `passport` varchar(20) DEFAULT NULL,
  `passport_expiry` date DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) DEFAULT NULL,
  `is_del` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`,`company_id`),
  UNIQUE KEY `employee_id_UNIQUE` (`employee_number`),
  UNIQUE KEY `authservice_id_UNIQUE` (`loginservice_id`),
  KEY `fk_employee_position_id_idx` (`position_id`),
  KEY `fk_employee_company_id_idx` (`company_id`),
  CONSTRAINT `fk_employee_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `fk_employee_position_id` FOREIGN KEY (`position_id`) REFERENCES `position` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee`
--

LOCK TABLES `Employee` WRITE;
/*!40000 ALTER TABLE `Employee` DISABLE KEYS */;
INSERT INTO `Employee` VALUES (1,1,'1','180720-218','Peter(SysAdmin)','','Gregory','Male','Silicon Valley','09235123123','Active','',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2018-07-20 16:26:34',NULL,0),(2,1,'11','180720-5','Katniss(Admin)',NULL,'Everdeen','Female','District 12','09236389861','Active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2018-07-20 16:29:43',NULL,0),(3,1,'23','180721-89','First Employee(Employee)',NULL,'Last Employee','Male',NULL,NULL,'Active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-07-20 16:35:05',NULL,0),(4,1,'24','180822-51','Archived SysAdmin(SysAdmin)',NULL,'Last Archived','Male',NULL,NULL,'Archived',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2018-07-20 16:36:01',NULL,0),(5,1,'52','000000-1','Deleted User(SysAdmin)',NULL,'Last Deleted','Female',NULL,NULL,'Archived',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-07-20 16:55:15',NULL,1),(7,1,'8','1','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:17:11',NULL,0),(12,1,'555','555','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:25:28',NULL,0),(14,1,'556','556','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:27:48',NULL,0),(16,1,'557','557','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:28:44',NULL,0),(18,1,'558','558','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:32:23',NULL,0),(20,1,'559','559','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:52:08',NULL,0),(22,1,'560','560','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:53:33',NULL,0),(23,1,'561','561','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:53:57',NULL,0),(25,1,'562','562','1','1','1','1','1','1','1','1',NULL,'1','1','1','1',NULL,1,NULL,NULL,'2018-07-23 11:54:19',NULL,0),(37,1,'564','564','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-23 14:12:50',NULL,0),(40,1,'565','565','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-23 14:20:54',NULL,0),(49,1,'566','566','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-23 14:31:49',NULL,0),(51,1,'567','567','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-23 15:48:42',NULL,0),(54,1,'568','568','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-24 13:44:45',NULL,0),(56,1,'569','569','asd','asd','asd','asd','asd','asd','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-24 13:45:09',NULL,0),(57,1,'999','999','Sample','Sample','Sample','female','Somewhere','123456789','asd','asd',NULL,'asd','asd','asd','asd',NULL,1,NULL,NULL,'2018-07-24 14:18:39',NULL,0);
/*!40000 ALTER TABLE `Employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `History`
--

DROP TABLE IF EXISTS `History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `History` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) NOT NULL,
  `date` date DEFAULT NULL,
  `regularization` date DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `competency` varchar(10) DEFAULT NULL,
  `grade` tinyint(1) DEFAULT NULL,
  `is_returning` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_history_postion_id_idx` (`position_id`),
  KEY `fk_history_employee_id_idx` (`employee_id`),
  CONSTRAINT `fk_history_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_history_postion_id` FOREIGN KEY (`position_id`) REFERENCES `position` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `History`
--

LOCK TABLES `History` WRITE;
/*!40000 ALTER TABLE `History` DISABLE KEYS */;
INSERT INTO `History` VALUES (1,49,NULL,NULL,1,'jkl',1,0,NULL,NULL,'2018-07-23 14:31:49',NULL),(2,1,NULL,NULL,1,'qwe',12,0,NULL,NULL,'2018-07-23 15:39:08',NULL),(3,1,NULL,NULL,1,'zxc',12,0,NULL,NULL,'2018-07-23 15:39:14',NULL),(4,51,NULL,NULL,1,'jkl',1,0,NULL,NULL,'2018-07-23 15:48:42',NULL),(5,54,NULL,NULL,1,'jkl',1,0,NULL,NULL,'2018-07-24 13:44:45',NULL),(6,56,NULL,NULL,1,'jkl',1,0,NULL,NULL,'2018-07-24 13:45:09',NULL),(7,57,NULL,NULL,1,'jkl',1,0,NULL,NULL,'2018-07-24 14:18:40',NULL);
/*!40000 ALTER TABLE `History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pan`
--

DROP TABLE IF EXISTS `Pan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) NOT NULL,
  `date` date DEFAULT NULL,
  `period` varchar(45) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `competency` varchar(10) DEFAULT NULL,
  `grade` tinyint(1) DEFAULT NULL,
  `reason` varchar(45) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pan_employee_id_idx` (`employee_id`),
  KEY `fk_pan_position_id_idx` (`position_id`),
  CONSTRAINT `fk_pan_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_pan_position_id` FOREIGN KEY (`position_id`) REFERENCES `position` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pan`
--

LOCK TABLES `Pan` WRITE;
/*!40000 ALTER TABLE `Pan` DISABLE KEYS */;
INSERT INTO `Pan` VALUES (1,1,'2018-07-23',NULL,NULL,'Comp 1',NULL,NULL,NULL,NULL,'2018-07-23 09:28:33',NULL),(2,1,NULL,NULL,NULL,'Comp 2',NULL,NULL,NULL,NULL,'2018-07-23 09:28:40',NULL),(3,1,NULL,NULL,NULL,'Comp 3',NULL,NULL,NULL,NULL,'2018-07-23 09:28:56',NULL);
/*!40000 ALTER TABLE `Pan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Position`
--

DROP TABLE IF EXISTS `Position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Position` (
  `id` int(11) NOT NULL,
  `definition` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Position`
--

LOCK TABLES `Position` WRITE;
/*!40000 ALTER TABLE `Position` DISABLE KEYS */;
INSERT INTO `Position` VALUES (1,'Sample Postion');
/*!40000 ALTER TABLE `Position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `id` int(11) NOT NULL,
  `definition` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'System Admin'),(2,'Admin'),(3,'HR'),(4,'Manager'),(5,'Employee');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RoleMap`
--

DROP TABLE IF EXISTS `RoleMap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RoleMap` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`employee_id`,`role_id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_rolemap_role_id_idx` (`role_id`),
  KEY `fk_rolemap_employee_id_idx` (`employee_id`),
  CONSTRAINT `fk_rolemap_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `fk_rolemap_role_id` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RoleMap`
--

LOCK TABLES `RoleMap` WRITE;
/*!40000 ALTER TABLE `RoleMap` DISABLE KEYS */;
INSERT INTO `RoleMap` VALUES (1,1,1,NULL,NULL,'2018-07-20 16:28:16',NULL),(2,2,2,NULL,NULL,'2018-07-20 16:37:06',NULL),(3,3,5,NULL,NULL,'2018-07-20 16:37:29',NULL),(4,4,1,NULL,NULL,'2018-07-20 16:38:04',NULL);
/*!40000 ALTER TABLE `RoleMap` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-24 17:39:21
